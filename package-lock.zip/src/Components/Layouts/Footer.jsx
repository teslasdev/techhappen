import React from 'react'

const Footer = () => {
  return (
    <div className='text-center py-6 text-white'>
       · Team TecHappen
    </div>
  )
}

export default Footer