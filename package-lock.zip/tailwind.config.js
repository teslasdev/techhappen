/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,jsx,css,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}